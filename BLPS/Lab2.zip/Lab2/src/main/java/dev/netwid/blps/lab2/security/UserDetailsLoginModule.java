package dev.netwid.blps.lab2.security;

import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;

import javax.security.auth.Subject;
import javax.security.auth.callback.*;
import javax.security.auth.login.LoginException;
import javax.security.auth.spi.LoginModule;
import java.util.Map;

public class UserDetailsLoginModule implements LoginModule {
    private Subject subject;
    private CallbackHandler callbackHandler;
    private UserDetailsService userDetailsService;
    private PasswordEncoder passwordEncoder;

    @Override
    public void initialize(
            Subject subject,
            CallbackHandler callbackHandler,
            Map<String, ?> sharedState,
            Map<String, ?> options) {

        System.out.println("Login module");

        this.subject = subject;
        this.callbackHandler = callbackHandler;
        this.userDetailsService = (UserDetailsService) options.get("userDetailsService");
        this.passwordEncoder = (PasswordEncoder) options.get("passwordEncoder");
    }

    @Override
    public boolean login() throws LoginException {
        System.out.println("Login");
        return true;


//        NameCallback nameCallback = new NameCallback("username");
//        PasswordCallback passwordCallback = new PasswordCallback("password", false);
//
//        try {
//            callbackHandler.handle(new Callback[]{nameCallback, passwordCallback});
//
//            String username = nameCallback.getName();
//            String password = new String(passwordCallback.getPassword());
//
//            // Аутентификация пользователя (например, проверка в базе данных)
//            if ("user".equals(username) && "password".equals(password)) {
//                return true;
//            } else {
//                throw new LoginException("Authentication failed");
//            }
//        } catch (Exception e) {
//            throw new LoginException("Authentication failed: " + e.getMessage());
//        }
    }

    @Override
    public boolean commit() throws LoginException {
        System.out.println("Commit");
        return true;
    }

    @Override
    public boolean abort() throws LoginException {
        return false;
    }

    @Override
    public boolean logout() throws LoginException {
        return false;
    }
}
