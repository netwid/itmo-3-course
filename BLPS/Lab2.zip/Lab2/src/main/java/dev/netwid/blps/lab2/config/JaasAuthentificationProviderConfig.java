package dev.netwid.blps.lab2.config;

import dev.netwid.blps.lab2.repository.UserRepository;
import dev.netwid.blps.lab2.security.UserRepositoryAuthorityGranter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.jaas.AbstractJaasAuthenticationProvider;
import org.springframework.security.authentication.jaas.AuthorityGranter;
import org.springframework.security.authentication.jaas.DefaultJaasAuthenticationProvider;

@Configuration
public class JaasAuthentificationProviderConfig {

}
