package dev.netwid.blps.lab2.enums;

public enum Role {
    USER,
    ADMIN
}
