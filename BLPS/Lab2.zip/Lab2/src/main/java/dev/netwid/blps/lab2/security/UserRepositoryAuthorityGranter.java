package dev.netwid.blps.lab2.security;

import java.security.Principal;
import java.util.Set;

import dev.netwid.blps.lab2.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.jaas.AuthorityGranter;

@RequiredArgsConstructor
public class UserRepositoryAuthorityGranter implements AuthorityGranter {
    private final UserRepository userRepository;

    @Override
    public Set<String> grant(Principal principal) {
        System.out.println("Granted");
        final var user = userRepository.findByUsername(principal.getName());
        return user.getRoles();
    }
}